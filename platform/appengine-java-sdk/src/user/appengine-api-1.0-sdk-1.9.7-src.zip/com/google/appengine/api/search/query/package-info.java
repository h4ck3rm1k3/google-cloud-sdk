@AppEngineInternal
package com.google.appengine.api.search.query;

import com.google.apphosting.api.AppEngineInternal;